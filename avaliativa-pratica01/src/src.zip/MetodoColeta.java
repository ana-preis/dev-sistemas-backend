public enum MetodoColeta {
    IN_LOCO;
}
