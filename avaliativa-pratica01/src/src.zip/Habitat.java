public enum Habitat {
    MATA_ATLANTICA,
    AR,
    PRAIA,
    OCEANO,
    LAGOA,
    RIO;
}
